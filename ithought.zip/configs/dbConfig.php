<?php
define ("db_host", "localhost");
define ("db_name", "thoughti");
define ("db_user", "root");
define ("db_pswd", "");
define ("db_charset", "utf8");
