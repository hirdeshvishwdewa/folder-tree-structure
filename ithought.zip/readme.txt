===================================
Welcome to brand new PHP Framework
===================================
Name of this Framework is "2Knight", because I created it in 2 nights (~12 hours).

Installation
============
1. Find database at /database/framework.sql
2. Configure database in /configs/dbConfig.php
3. Done! go to http://yourdomain.com/myAwesomeFramework/index.php

